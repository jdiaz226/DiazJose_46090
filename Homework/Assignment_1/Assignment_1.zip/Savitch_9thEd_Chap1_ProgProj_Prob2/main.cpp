/* 
 * File:   main.cpp
 * Author: Jose Diaz
 * Created on June 23, 2015, 11:42 PM
 * Purpose: Display "CS!" and "Computer Science is Cool Stuff"
 */

//System Libraries
#include <iostream>  //File I/O
using namespace std; //std namespace -> iostream

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    
    //Input Values Here
    
    //Process Input Here
    
    //Output Unknowns Here
    cout<<"**************************************"<<endl;
    
    cout<<"        CCC          SSSS      !!"<<endl;
    cout<<"       C   C        S    S     !!"<<endl;
    cout<<"      C            S           !!"<<endl;
    cout<<"     C              S          !!"<<endl;
    cout<<"     C               SSSS      !!"<<endl;
    cout<<"     C                   S     !!"<<endl;
    cout<<"      C                   S    !!"<<endl;
    cout<<"       C   C        S    S       "<<endl;
    cout<<"        CCC          SSSS      00"<<endl;
    
    cout<<"**************************************"<<endl;
            
    cout<<"Computer Science is Cool Stuff!!!"<<endl;
    
    //Exit Stage Right!
    return 0;
}
