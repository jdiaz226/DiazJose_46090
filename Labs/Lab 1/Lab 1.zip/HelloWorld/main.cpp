/* 
 * File:   main.cpp
 * Author: Jose Diaz
 * Created on June 23, 2015, 11:42 PM
 * Purpose: First Program to test the IDE
 */

//System Libraries
#include <iostream>  //File I/O
using namespace std; //std namespace -> iostream

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    
    //Input Values Here
    
    //Process Input Here
    
    //Output Unknowns Here
    cout<<"Hello World"<<endl;
    //Exit Stage Right!
    return 0;
}

